

To execute:

yarn tsx src/index.ts